file=open("sample.txt", "rb")
'''for line in file:
    print(line.strip())'''  

data=file.read()
print(data)
file.close()
