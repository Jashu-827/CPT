# file=open("sample_binry.bin", "wb")
# file.write("b \x48\x65\x6c\x6c\x")
# file.close()

with open ("sample_binary.bin", "wb") as file:
    data=b'\x48\x65\x6c\x6c\x6f'
file.write(data)