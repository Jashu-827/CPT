import os
os.remove("empty.txt")
print("Successfully........deleted")