# f=open("file1.txt", 'w')
# f.write("Hello")
# print(f.isatty())
import sys
# print("Python version:", sys.version)
# age=int(input("Enter age:"))
# if age<18:
#     print("Not eligible to drive.....")
#     sys.exit()
# print("You are eligible......")
print("Platform: ", sys.platform)

