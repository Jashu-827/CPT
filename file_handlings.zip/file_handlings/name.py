import os
os.rename("sample.txt", "jashu.txt")
print("Sucessfully renamed.......")