with open("file1.txt",'w+') as f:
    f.write("Hello sir!!!!")
    f.seek(0)
    data=f.read()
    print("Previoous:",data)
    new_data=data.replace("sir!!!!", "Jaswanth")
    f.seek(0)
    f.write(new_data)
    f.truncate()

# with open("file1.txt", 'r+') as f:
#     data=f.read()
#     print("Previos:", data)
#     new_data=data.replace("Tattukuri", "jashu")
#     f.seek(0)
#     f.write(new_data)
#     f.truncate()

with open("file1.txt",'r') as f:
    print("Latest", f.read())